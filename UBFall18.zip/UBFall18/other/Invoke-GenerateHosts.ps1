Function Invoke-GenerateHosts{
     <#
    .SYNOPSIS
    This cmdlet is used to generate a list of IPs given a list of base IPs, number of teams, and the octet where the
    team number is located

    Function: Invoke-GenerateHosts
    Author: Russell Babarsky  

    .PARAMETER BaseIpList
    A comma seperated list that has the IPs

    .PARAMETER MaxTeams
    Max number of teams. Inclusive

    .PARAMETER Octet
    Octet to change from 1-4 (NOT array indexing)

    .PARAMETER Filename
    Output Filename

    .EXAMPLE
    Invoke-GenerateHosts -BaseIpList "10.0.X.10, 10.0.X.150" -MaxTeams 12 -Octet 3

    #>

    Param(
        [Parameter(Mandatory = $true)]
            [String]$BaseIpList,
        [Parameter(Mandatory = $true)]
            [Int]$MaxTeams,
        [Parameter(Mandatory = $true)]
            [int]$Octet,
        [Parameter()]
            [string]$Filename = "hosts"
    )

    Write-Debug "Got Parameter $BaseIpList"

    $BaseIpList = $BaseIpList.Replace(' ','')

    $IpList = @()
    $IpList = $BaseIpList.Split(',')
    
    $Octet = $Octet - 1
    $Start = 0
   
   $FinalHostList = @()
   foreach($i in $start..$MaxTeams){
       foreach($j in $IpList){
           $Octets = $j.Split('.')
           $Octets[$Octet] = $i
           $New = $Octets -join "."
           $FinalHostList += $New
       }
    }

    $FinalHostList | Out-File $Filename

}

Invoke-GenerateHosts -BaseIpList '10.X.1.50,10.X.1.40,10.X.1.60' -MaxTeams 15 -Octet 2